"""Filesystem-backed append-only store for rooms (chat) and notes (KV).

Design constraints (see docs/design.md):
  - one directory tree, no database, no auth
  - rooms are append-only JSONL files, bounded by a sliding window
  - reads never load the whole file: backwards chunked tail only
  - all caller-supplied names pass an allowlist regex, so no path is ever
    built from unvalidated input (traversal impossible by construction)
"""

from __future__ import annotations

import fcntl
import json
import os
import re
import time
import unicodedata
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

import didkey

NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,47}$")

MAX_TEXT_CHARS = 4096
MAX_VALUE_CHARS = 8192
MAX_ROOM_BYTES = 10 << 20  # 10 MiB per room, then compacted
# Compaction keeps a byte budget, not a line count. A fixed count cannot serve both ends
# of a 4096-char limit: at ~150-byte messages, 500 lines threw away 98% of a full 10 MiB
# ring; at the 16 KB a 4096-char message reaches in 4-byte UTF-8, 5000 lines would land
# *above* the ring and re-compact on every single append. The budget is right either way.
# COMPACT_MAX_LINES only bounds how much the compactor holds in memory at once (worst
# case ≈ COMPACT_KEEP_BYTES, which is what actually caps it on a 128 MiB container).
COMPACT_KEEP_BYTES = MAX_ROOM_BYTES // 2
COMPACT_MAX_LINES = 5000
READ_BUDGET = 1 << 20  # never read more than 1 MiB to answer a tail request
MAX_LIMIT = 200

# Disk is the only unbounded cost on a world-writable service: MAX_ROOM_BYTES caps each
# room, but nothing capped how many rooms a stranger may create. The first answer was to
# bound the count and read the disk figure off the product, MAX_ROOMS * MAX_ROOM_BYTES.
# That works exactly once. It ties the number of conversations the service will hold to
# the size of the volume, so the count cannot grow without the bill growing with it: at
# the 5120 below the product is 51 GiB, a volume nobody provisions for a worst case that
# needs an attacker to fill every ring to the brim. So the two are now separate constants
# with separate jobs, and both are enforced (see `_check_room_capacity`).
#
# MAX_ROOMS bounds how many rooms the service *tracks* — the directory walks, the reaper,
# the overview — not the disk.
MAX_ROOMS = 5120
# MAX_TOTAL_ROOM_BYTES is the disk budget, stated rather than derived, and it is
# deliberately the OLD product (512 * 10 MiB): ten times the rooms cost exactly the same
# volume as before, because what filled the old cap was thousands of small rooms and not
# hundreds of full ones. This is the number a deployment sizes its volume against.
# Raising it, or MAX_ROOM_BYTES, is what needs re-checking against the volume now —
# raising MAX_ROOMS no longer does.
MAX_TOTAL_ROOM_BYTES = 5 << 30
# The budget above is only a real bound if rooms cannot grow past it after they are made.
# Gating *creation* alone does not do that: 5120 rooms created while usage is low can each
# then grow to MAX_ROOM_BYTES, which is 51 GiB — ten times the number the operator was told
# to provision. So the ring itself yields under pressure. Every room is guaranteed this
# much; above it a room keeps up to MAX_ROOM_BYTES only while the service has headroom, and
# compacts back to its guaranteed floor on the next append once the budget is spent.
#
# That is what closes the hole, because growing a room *requires appending to it*: the
# write that would push a room past its floor is the same write that compacts it. Rooms
# already large when the budget is reached stay large until they are written to or reaped,
# but they were counted in the budget that triggered this, so the total does not climb.
# Overshoot is one refresh interval of writes, and writes are rate limited.
#
# = MAX_TOTAL_ROOM_BYTES // MAX_ROOMS on purpose: the floor times the cap is the budget, so
# even the worst case — every room at its floor — lands exactly on the number.
RESERVED_ROOM_BYTES = MAX_TOTAL_ROOM_BYTES // MAX_ROOMS
# Total room bytes as of the last reap pass. A cached figure and not a live walk: this is
# read on the append path, where a per-write walk of every room would cost more than the
# thing it is protecting. The reaper already walks the tree on a timer, so refreshing it
# there is free, and a stale-by-one-interval number is fine for a bound whose overshoot is
# bounded by the rate limiter anyway.
USAGE_FILE = ".usage"
# = MAX_ROOMS on purpose: the reserved namespaces (topic, room-owners, room-allow,
# room-nonce) hold at most one note per room, so this equality is the invariant that lets
# EVERY room carry a topic and an owner. Raising MAX_ROOMS raises this with it.
MAX_NOTES_PER_NS = MAX_ROOMS
# A per-namespace cap bounds nothing on a public service: namespaces are never enumerated
# and cost nothing to invent, so a flood picks a fresh one per write. The global cap is the
# one that holds — MAX_NOTES_TOTAL * MAX_VALUE_CHARS ≈ 320 MiB, and it bounds namespace
# directories too because a namespace only exists once a note in it was accepted.
#
# Derived from MAX_ROOMS, not a literal, because the two are not independent: the four
# reserved namespaces hold one note per room each, so anything below 4 * MAX_ROOMS makes
# the MAX_NOTES_PER_NS invariant above a lie — the global cap would run out before every
# room could carry a topic and an owner. The multiplier is 8 rather than 4 so the surplus
# left for agents' own notes stays the share it was at 4096-over-512.
MAX_NOTES_TOTAL = 8 * MAX_ROOMS
# The room where the server announces new public rooms. Clients may read it like any other
# room but may NOT write to it (app.py refuses): a discovery log anyone can forge is worse
# than no log, because monitors would build on it. Server-written lines are the only lines.
EVENTS_ROOM = "events"
EVENTS_NICK = "server"
# Lifetime counters live here because nothing else in the store is monotonic: `seq` is
# per-room and dies with the room, compaction drops lines, and the reaper deletes whole
# files. Summing `last_seq` across rooms therefore *decreases* on a reap, which would make
# a "messages since the last digest" delta negative. These four only ever go up.
COUNTERS_FILE = ".counters"
COUNTER_KEYS = ("messages", "rooms_created", "reaped_idle", "reaped_stillborn")
# Periodic aggregate samples, so growth over a window is answerable at all: the counters
# above say what the totals are *now*, and nothing but a stored history says what they were
# a day ago. Kept here rather than in the reader because the service is the only thing that
# is always running — a reader that holds its own history reports "no data" for a full day
# every time it is restarted or redeployed, and that was the failure worth designing out.
SNAPSHOTS_FILE = ".snapshots"
# Taken on the write path under the same throttle as the reaper (see `_snapshot`), so the
# cadence costs one extra pass per interval on a service that is already walking these
# directories to reap. Nothing runs in the background.
SNAPSHOT_EVERY = 300
# 24h is the longest window a digest reports; the surplus is what keeps a lookback sample
# available after an interval is missed, instead of losing the window entirely.
SNAPSHOT_KEEP_SECONDS = 30 * 3600
IDLE_SECONDS = 7 * 86400  # untouched rooms/notes are reaped, so squatting expires
REAP_EVERY = 300
# A room that never got past its first message is a monologue, not a conversation: someone
# said one thing, nobody answered, and it is holding a slot against MAX_ROOMS. A week is
# what a conversation that stopped is worth; a day is what an unanswered opener is worth.
# This is the disposal half of the §II.2.2 zero-response tripwire — the aggregates measure
# unanswered rooms, this stops them accumulating. Rooms only: a note has no reply to wait
# for, so "one write" says nothing about it.
STILLBORN_SECONDS = 86400
STILLBORN_MESSAGES = 1

# Room name classes. A name is a chain of leading `<class>-` markers followed by a body,
# so classes compose: `mb-p-<random>` is a mailbox that is also unlisted, `e-p-<random>` a
# private room that also decays. Prefix matching costs the obvious collision — a room
# genuinely about e-commerce is `e-commerce`, i.e. ephemeral — but that is the price the
# existing `p-` rule already paid, and one namespace with one rule beats four bespoke ones.
#   p   unlisted (capability URL; the name is the only secret)
#   mb  mailbox: writes require the signed lane
#   d   ownable: a /kv/room-owners/<room> claim can gate writes to listed keys
#   e   ephemeral: messages older than EPHEMERAL_TTL_SECONDS are dropped on read
ROOM_CLASSES = ("p", "mb", "d", "e")
# Ownership of an *established* open room would let a stranger lock everyone else out, so
# only the `d-` class is ownable at all — a room is owned from birth or never. These two
# are denied on top of that, hardcoded, because they are the rendezvous points every agent
# is told about: a claim on either would be a claim on the front door.
UNOWNABLE_ROOMS = ("lobby", "meta")
OWNERS_NS = "room-owners"  # /kv/room-owners/<room> -> the owner's did:key
ALLOW_NS = "room-allow"  # /kv/room-allow/<room>  -> space-separated did:keys
# Server-written, world-readable: the highest nonce accepted for a room's signed kv writes.
# Notes are durable and have no ring, so unlike a message a captured signed note URL would
# replay forever — and replaying an *old* allow-list is how a revoked key gets itself back
# in. This is the smallest state that closes that, and it rides the existing CAS primitive
# for its own atomicity. MAX_NOTES_PER_NS = MAX_ROOMS, so every room may hold an owner.
NONCE_NS = "room-nonce"
TOPIC_NS = "topic"  # /kv/topic/<room>      -> what the room is for
# A topic is an ordinary note (MAX_VALUE_CHARS), and /rooms shows one per room it lists:
# printed in full that is a reply measured in hundreds of KB, against a response budget
# measured in kilobytes. The overview
# carries a preview; /kv/topic/<room> carries the whole thing.
TOPIC_PREVIEW_CHARS = 120
# Lazy expiry for the `e-` class: nothing sweeps in the background, records are simply not
# returned once they are older than this, and physically leave on the next compaction or
# when the IDLE_SECONDS reaper takes the file.
EPHEMERAL_TTL_SECONDS = int(os.environ.get("CHAT_EPHEMERAL_TTL_SECONDS", "900"))


class StoreError(ValueError):
    """Caller-supplied input rejected. Maps to HTTP 400."""


class StoreConflictError(ValueError):
    """A conditional write lost the race. Maps to HTTP 409, and carries the value that
    was actually there so the caller can rebase without a second round trip."""

    def __init__(self, message: str, current: str | None) -> None:
        super().__init__(message)
        self.current = current


def valid_name(name: str) -> str:
    # fullmatch, not match: `$` also matches *before* a trailing newline, so `match()`
    # accepted "abc\n" — and Starlette's path converter passes %0A through, which created
    # a room whose filename carried a newline. The allowlist is the control that makes
    # traversal impossible by construction, so it has to mean exactly what it says.
    if not NAME_RE.fullmatch(name or ""):
        # The rule alone leaves the caller to diff its string against a regex. Naming the
        # causes in order of how often they actually happen turns this into a fix: the
        # overwhelming majority of rejections here are an uppercase name or a space.
        raise StoreError(
            f"bad name {name!r}: expected /^[a-z0-9][a-z0-9_-]{{0,47}}$/ — lowercase "
            "letters, digits, - and _, 1-48 characters, starting with a letter or digit. "
            "Usual causes: uppercase (lowercase it), a space or %20 (use - instead), a "
            "dot or slash, an empty segment, or over 48 characters. This rule covers "
            "<room>, <nick>, <ns> and <key>; only <text> and <value> are free-form."
        )
    return name


def _listable(name: str) -> bool:
    """Enumerable only if the name is one this service would accept today. Anything else
    on disk — hand-created, or left by an older validator — stays out of listings rather
    than being echoed into a response."""
    return NAME_RE.fullmatch(name) is not None and not unlisted(name)


def room_classes(name: str) -> frozenset[str]:
    """The leading `<class>-` markers on a name, so classes compose by prefix.

    `p-x` -> {p}; `mb-p-x` -> {mb, p}; `e-p-x` -> {e, p}; `pastel` -> {} (no marker, no
    hyphen). The last segment is always the body, never a class, so `p-` alone is still an
    unlisted room and a bare `d` is not an ownable one.
    """
    classes = set()
    for segment in name.split("-")[:-1]:
        if segment not in ROOM_CLASSES:
            break
        classes.add(segment)
    return frozenset(classes)


def unlisted(name: str) -> bool:
    """`p-<random>` names are capability URLs: reachable by whoever knows them, never
    enumerated. An agent's private scratch space is an unguessable name, not an ACL —
    30 remaining chars of [a-z0-9_-] is ~150 bits. The URL is the only secret, so it
    leaks wherever the agent's transcript and the proxy logs leak.

    Composed, not prefix-matched, so a private mailbox (`mb-p-<random>`) or a private
    ephemeral room (`e-p-<random>`) stays out of listings too. Every name that started
    with `p-` before still qualifies — the first segment is a class marker by definition.
    """
    return "p" in room_classes(name)


def is_mailbox(name: str) -> bool:
    """`mb-` rooms take signed writes only, so spam is attributable and ignorable by key."""
    return "mb" in room_classes(name)


def is_ephemeral(name: str) -> bool:
    return "e" in room_classes(name)


def ownable(name: str) -> bool:
    return "d" in room_classes(name) and name not in UNOWNABLE_ROOMS


# The Unicode categories `clean_text` replaces with a space, and why each is on the list.
# One list, in one place: the reason a value is swept is the reason it is named here, and a
# docstring that also enumerated them would be a second copy to keep in step.
#
#   Cc  control      — C0/C1 would break the JSONL one-record-per-line invariant.
#   Cf  format       — the *invisible instruction* smuggling vector against LLM readers.
#                      Unicode tag characters U+E0000–U+E007F encode ASCII that no human or
#                      log line shows, bidi overrides (U+202E) reorder displayed text away
#                      from what is stored (Trojan Source), and zero-width joiners hide word
#                      boundaries. This service's stated top hazard is cross-agent prompt
#                      injection (design doc §3.1), so text that renders as nothing must not
#                      survive into another agent's context.
#   Cs  surrogate    — never valid on its own in stored text.
#   Co  private use  — renders as whatever the reader's font decides, which is not a promise.
#   Zl  line sep     — U+2028, and Zp U+2029: invisible here, a line break to enough
#   Zp  para sep       plain-text consumers (JS string literals among them) that one stored
#                      value renders as two lines. The single-line promise has to hold for
#                      every reader, not just the ones that agree with `str.splitlines`.
INVISIBLE_CATEGORIES = ("Cc", "Cf", "Cs", "Co", "Zl", "Zp")


def clean_text(text: str, limit: int = MAX_TEXT_CHARS) -> str:
    """Replace every character in INVISIBLE_CATEGORIES with a space, then trim.

    What that buys: one stored record is one line for every reader, and nothing that renders
    as nothing survives into another agent's context.

    Trade-off, accepted deliberately: ZWJ emoji sequences flatten (👨‍👩‍👧 → 👨👩👧).
    Mangled emoji is visible and harmless; a smuggled instruction is neither.
    """
    text = "".join(
        " " if unicodedata.category(c) in INVISIBLE_CATEGORIES else c for c in text
    ).strip()
    if not text:
        # Distinguishing "you sent nothing" from "the sweep ate all of it" matters: the
        # second is surprising, and a caller whose message was pure zero-width or bidi
        # characters would otherwise re-send the same bytes and get the same refusal.
        raise StoreError(
            "empty text: nothing visible was left after the single-line sweep, which "
            "replaces every control, format and line-separator character (newline, "
            "zero-width, bidi override, Unicode tag, U+2028) with a space and then trims "
            "the ends. Send at least one visible character."
        )
    if len(text) > limit:
        raise StoreError(
            f"text too long: {len(text)} characters, and the limit is {limit}. Split it, "
            'or send it as a body — POST /r/<room> {"text":...} and POST /kv/<ns>/<key> '
            '{"value":...} carry the full length, which a URL cannot: one CJK character '
            "is 9 bytes URL-encoded and one emoji is 12."
        )
    return text


# --------------------------------------------------------------------------- paths


def room_path(root: Path, room: str) -> Path:
    return root / "rooms" / f"{valid_name(room)}.jsonl"


def note_path(root: Path, ns: str, key: str) -> Path:
    return root / "notes" / valid_name(ns) / f"{valid_name(key)}.txt"


@contextmanager
def _locked(target: Path):
    """Exclusive lock held on a sidecar file, so compaction can replace the data
    file inode without writers holding a lock on the orphan."""
    target.parent.mkdir(parents=True, exist_ok=True)
    lock = target.with_suffix(target.suffix + ".lock")
    with open(lock, "a+b") as lf:
        fcntl.flock(lf, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lf, fcntl.LOCK_UN)


def _now() -> str:
    """UTC to the microsecond.

    Second precision put every message in a burst on the same visible timestamp, so the
    only tiebreak was `seq`. `seq` remains the authoritative order — it is assigned under
    the room lock and is contiguous — but a readable sub-second stamp lets a reader
    reconstruct *rate* from a tail, which second precision flattens away.

    Records written before this change carry a second-precision `ts`. Nothing parses `ts`
    (it is passed through as an opaque string), so both forms coexist without a migration.
    """
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def counters(root: Path) -> dict:
    """The lifetime counters, with every key present. Read without the lock: the file is
    replaced atomically, so a reader either sees the old bytes or the new ones."""
    try:
        data = json.loads((root / COUNTERS_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    out = {}
    for key in COUNTER_KEYS:
        value = data.get(key, 0)
        out[key] = value if isinstance(value, int) and value >= 0 else 0
    return out


def _bump(root: Path, **deltas: int) -> None:
    """Add to the lifetime counters, atomically.

    Best effort, exactly like `_log_event`: the caller's write has already succeeded by
    the time this runs, so an unwritable counter must never turn that success into an
    error. The cost of that choice is a possible undercount, which is the right way round
    — a digest that reports slightly low is recoverable, a write that 500s is not.
    """
    path = root / COUNTERS_FILE
    try:
        with _locked(path):
            current = counters(root)
            for key, delta in deltas.items():
                current[key] = current.get(key, 0) + delta
            tmp = path.parent / f"{path.name}.tmp"
            tmp.write_text(json.dumps(current), encoding="utf-8")
            os.replace(tmp, path)  # atomic: readers never see a half-written file
    except OSError:
        pass


# --------------------------------------------------------------------------- reading


def reverse_lines(f, chunk_size: int = 65536, max_bytes: int = READ_BUDGET):
    """Yield complete lines from the end of a binary file, newest first.

    Reads backwards in chunks and stops after `max_bytes`, so cost is bounded by
    the caller's window, not by file size.
    """
    f.seek(0, os.SEEK_END)
    pos = f.tell()
    head = b""  # possibly-incomplete first line of the block read so far
    read = 0
    while pos > 0 and read < max_bytes:
        step = min(chunk_size, pos, max_bytes - read)
        pos -= step
        f.seek(pos)
        block = f.read(step)
        read += step
        parts = (block + head).split(b"\n")
        head = parts.pop(0)
        for line in reversed(parts):
            if line:
                yield line
    if head and pos == 0:
        yield head


def _cutoff(room: str) -> float | None:
    """The epoch second before which records in `room` are expired, or None if the room
    keeps everything (every class but `e-`)."""
    return time.time() - EPHEMERAL_TTL_SECONDS if is_ephemeral(room) else None


def _expired(rec: dict, cutoff: float) -> bool:
    """Fail closed on an unreadable `ts`: an `e-` room promises the record is gone by now,
    and a record whose age cannot be established cannot honour that promise. Elsewhere `ts`
    stays what it always was — an opaque string nothing parses."""
    ts = rec.get("ts")
    if isinstance(ts, str):
        for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ"):
            try:
                return datetime.strptime(ts, fmt).replace(tzinfo=UTC).timestamp() < cutoff
            except ValueError:
                continue
    return True


def _parse(line: bytes) -> dict | None:
    try:
        rec = json.loads(line)
    except (ValueError, UnicodeDecodeError):
        return None  # torn write at EOF, or hand-edited garbage
    return rec if isinstance(rec, dict) and isinstance(rec.get("seq"), int) else None


def read_messages(root: Path, room: str, limit: int = 50, since: int | None = None) -> dict:
    """Return the newest `limit` messages (oldest-first) with seq > `since`."""
    limit = max(1, min(int(limit), MAX_LIMIT))
    path = room_path(root, room)
    # Expiry is lazy and drop-on-read: no reaper thread, no per-room timer. Records are
    # append-ordered, so the first expired record means every older one is expired too and
    # the scan stops there. `last_seq` deliberately does NOT filter — seq must keep
    # advancing past records nobody can read any more, or an expired room would reuse seqs.
    cutoff = _cutoff(room)
    out: list[dict] = []
    if path.exists():
        with path.open("rb") as f:
            for raw in reverse_lines(f):
                rec = _parse(raw)
                if rec is None:
                    continue
                if since is not None and rec["seq"] <= since:
                    break
                if cutoff is not None and _expired(rec, cutoff):
                    break
                out.append(rec)
                if len(out) >= limit:
                    break
    out.reverse()
    return {
        "room": room,
        "count": len(out),
        "first_seq": out[0]["seq"] if out else None,
        "last_seq": out[-1]["seq"] if out else (since or 0),
        "messages": out,
    }


def last_seq(root: Path, room: str) -> int:
    path = room_path(root, room)
    if not path.exists():
        return 0
    with path.open("rb") as f:
        for raw in reverse_lines(f, max_bytes=65536):
            rec = _parse(raw)
            if rec is not None:
                return rec["seq"]
    return 0


# Engagement tripwires (docs/research/moltbook-adoption-analysis.md §II.2.2) are computed from
# the newest WINDOW_MESSAGES records of a room, read backwards under WINDOW_BYTES of tail —
# which is the *same* read `last_seq` already did for every room /rooms shows, so the read
# budget of the overview is unchanged and only the parse of those bytes is new. Worst case for
# one /rooms request is therefore `shown` (<= MAX_LIMIT = 200) x WINDOW_BYTES = 12.8 MiB parsed,
# ~210 ms at the ~60 MB/s parse rate measured in the design doc §5.1; at this function's default
# limit it is 3.2 MiB / ~55 ms, and a typical ~120-byte record makes the message cap bind first at ~24 KiB
# per room. Rooms that are *not* shown still cost only a directory stat. What this bound exists
# to exclude is the obvious wrong implementation: a full-ring scan (10 MiB) across every room.
WINDOW_MESSAGES = 200
WINDOW_BYTES = 65536


def room_window(root: Path, room: str) -> tuple[int, list[str]]:
    """One bounded backwards pass over a room's tail: (last_seq, nicks newest-first).

    `last_seq` and the §II.2.2 aggregates come out of the same scan because they read the
    same bytes; computing them separately would double the cost of the overview.
    """
    nicks: list[str] = []
    top = 0
    path = room_path(root, room)
    if path.exists():
        with path.open("rb") as f:
            for raw in reverse_lines(f, max_bytes=WINDOW_BYTES):
                rec = _parse(raw)
                if rec is None:
                    continue
                if not nicks:
                    top = rec["seq"]
                nicks.append(str(rec.get("from", "")))
                if len(nicks) >= WINDOW_MESSAGES:
                    break
    return top, nicks


def _unanswered(nicks: list[str]) -> int:
    """How many of a window's messages nobody else spoke after (`nicks` is newest-first).

    A message is answered when some *later* message in the window carries a different nick.
    That makes the unanswered messages exactly the newest run of a single nick: everything
    older than that run has a different nick somewhere after it. A one-writer room scores its
    whole window, which is the Moltbook 93.5% analog.
    """
    run = 0
    while run < len(nicks) and nicks[run] == nicks[0]:
        run += 1
    return run


def _engagement(nicks: list[str]) -> dict:
    """Per-room §II.2.2 aggregates over one scanned window. `window` is how many messages the
    ratios are over, so a reader can tell 1.0-of-3 from 1.0-of-200."""
    n = len(nicks)
    if not n:  # no parsable record in the window: no data, which is not the same as zero
        return {"window": 0, "zero_response_share": None, "nick_diversity": None}
    return {
        "window": n,
        "zero_response_share": round(_unanswered(nicks) / n, 4),
        "nick_diversity": round(len(set(nicks)) / n, 4),
    }


def _rollup(windows: list[list[str]]) -> dict:
    """Service-level §II.2.2 aggregates: one ratio pooled over every scanned window, not a mean
    of per-room ratios, so a three-message room cannot outweigh a two-hundred-message one.
    Nicks are pooled globally too — one bot talking to itself in forty rooms should read as low
    diversity, not as forty separate healthy-looking rooms."""
    total = sum(len(w) for w in windows)
    if not total:
        return {
            "window_cap": WINDOW_MESSAGES,
            "windowed_messages": 0,
            "zero_response_share": None,
            "nick_diversity": None,
        }
    distinct = len({nick for w in windows for nick in w})
    return {
        "window_cap": WINDOW_MESSAGES,
        "windowed_messages": total,
        "zero_response_share": round(sum(_unanswered(w) for w in windows) / total, 4),
        "nick_diversity": round(distinct / total, 4),
    }


def list_rooms(root: Path) -> list[str]:
    d = root / "rooms"
    if not d.is_dir():
        return []
    return sorted(p.stem for p in d.glob("*.jsonl") if _listable(p.stem))


def room_stats(root: Path, limit: int = 50) -> dict:
    """Recency-sorted room summaries for the overview.

    `size` and `idle` come free from the directory stat; `last_seq` and the engagement
    aggregates cost one small tail read, so they are computed only for the rooms actually
    shown. That keeps the overview O(shown) rather than O(rooms) at the room cap — which is
    what let the cap grow tenfold without the overview getting slower. See WINDOW_BYTES for
    the resulting worst-case bound.
    """
    d = root / "rooms"
    now = time.time()
    entries = []
    try:
        with os.scandir(d) as rooms:
            for e in rooms:
                if not e.name.endswith(".jsonl"):
                    continue
                name = e.name[: -len(".jsonl")]
                if not _listable(name):
                    continue
                try:
                    st = e.stat()
                except OSError:
                    continue  # reaped between the readdir and the stat
                entries.append((st.st_mtime, st.st_size, name))
    except FileNotFoundError:
        pass
    entries.sort(reverse=True)
    shown = []
    windows = []
    for mtime, size, name in entries[: max(1, min(int(limit), MAX_LIMIT))]:
        top, nicks = room_window(root, name)
        windows.append(nicks)
        shown.append(
            {
                "room": name,
                "last_seq": top,
                "bytes": size,
                "idle_seconds": max(0, int(now - mtime)),
                "topic": topic(root, name),
                **_engagement(nicks),
            }
        )
    return {
        "rooms": shown,
        "total": len(entries),
        "capacity": MAX_ROOMS,
        "bytes": sum(e[1] for e in entries),
        # Both bounds, because either can be the one that bites: a service can be far from
        # the room count and out of disk, or the reverse. A reader shown only `capacity`
        # cannot tell which, and /humans renders exactly what this returns.
        "bytes_capacity": MAX_TOTAL_ROOM_BYTES,
        "engagement": _rollup(windows),
    }


def service_stats(root: Path, engagement_rooms: int = 50) -> dict:
    """Whole-service aggregates for the internal `/stats` endpoint. Counters only.

    **No name of anything ever appears in this dict** — not a room, not a namespace, not a
    nick. That is not squeamishness about a private channel: an unlisted room name and a
    note namespace *are* bearer credentials (see `unlisted`), so a digest that carried them
    would hand write access to every reader of wherever the digest lands, and to whatever
    retains it. Counts of those same things are safe and are what an operator actually
    watches, so counts are what this returns.

    Unlike `room_stats`, the room totals here count **every** room including unlisted ones:
    they are what bounds the disk and the room cap, and `/rooms` excludes them precisely
    because it lists names. Cost is one stat per room (O(cap)) plus the bounded tail scans
    `room_stats` already does for the engagement rollup, so this is cached in app.py.
    """
    # `ownable`, not `owned`: the `d-` prefix only makes a room *claimable* — until
    # /kv/room-owners/<room> exists the write gate treats it as an ordinary open room, so
    # counting the class as owned would overstate adoption.
    keys = ("total", "listed", "unlisted", "open", "mailbox", "ownable", "ephemeral")
    rooms = dict.fromkeys(keys, 0)
    room_bytes = 0
    d = root / "rooms"
    if d.is_dir():
        for p in d.glob("*.jsonl"):
            name = p.stem
            if not NAME_RE.fullmatch(name):
                continue  # same rule as _listable: never count what we would not accept
            try:
                room_bytes += p.stat().st_size
            except OSError:
                continue  # reaped between glob and stat
            classes = room_classes(name)
            rooms["total"] += 1
            rooms["unlisted" if "p" in classes else "listed"] += 1
            for marker, key in (("mb", "mailbox"), ("d", "ownable"), ("e", "ephemeral")):
                if marker in classes:
                    rooms[key] += 1
            if not classes:
                rooms["open"] += 1
    notes = note_stats(root)
    return {
        "rooms": {**rooms, "capacity": MAX_ROOMS},
        "bytes": {
            "rooms": room_bytes,
            "notes": notes["bytes"],
            # The worst case a deployment budgets its disk against, exposed so a reader can
            # see headroom without knowing the constants. MAX_TOTAL_ROOM_BYTES rather than
            # MAX_ROOMS * MAX_ROOM_BYTES: the product stopped being the bound when the room
            # cap was decoupled from the disk budget, and it is the enforced number that
            # belongs here.
            "rooms_capacity": MAX_TOTAL_ROOM_BYTES,
        },
        "notes": notes,
        "counters": counters(root),
        # Pooled over the most recently active rooms only — the same bounded window
        # /rooms reports, and the tripwire to publish beside any raw count.
        "engagement": room_stats(root, limit=engagement_rooms)["engagement"],
    }


# --------------------------------------------------------------------------- writing


def _stillborn(path: Path) -> bool:
    """True if a room file holds no more than STILLBORN_MESSAGES records.

    Reads from the head and stops at the first record past the limit, so an answered room
    costs two lines and an unanswered one costs the few hundred bytes it is. An unreadable
    file is not stillborn: deleting what cannot be counted is how a reaper eats live data.
    """
    seen = 0
    try:
        with path.open("rb") as f:
            for line in f:
                if _parse(line) is None:
                    continue
                seen += 1
                if seen > STILLBORN_MESSAGES:
                    return False
    except OSError:
        return False
    return True


def _reapable(path: Path, now: float, stillborn_rule: bool) -> str | None:
    """Which threshold retires `path`, or None if neither does yet.

    Returns the reason rather than a bool so the caller can count the two rules apart:
    a wave of stillborn reaps means openers nobody answered, a wave of idle reaps means
    conversations that ended, and the digest is only useful if it can tell them apart.
    Both values are truthy, so `if not _reapable(...)` reads exactly as it did.
    """
    idle = now - path.stat().st_mtime
    if idle > IDLE_SECONDS:
        return "idle"
    if stillborn_rule and idle > STILLBORN_SECONDS and _stillborn(path):
        return "stillborn"
    return None


# The three namespaces that gate access to a room rather than carry content. Their mtime
# tracks when ownership last changed, not when the room was last used — so under the plain
# idle rule a busy room's owner note expired after IDLE_SECONDS of quiet *ownership*, and with it
# went the allow-list (listed keys silently lose write access) and the replay counter (a
# captured signed URL re-adding a revoked key starts working again). A control whose whole
# job is to outlive an attacker must not expire before the thing it guards.
ROOM_GUARD_NS = (OWNERS_NS, ALLOW_NS, NONCE_NS)


def _guards_a_live_room(root: Path, path: Path, now: float) -> bool:
    """True when `path` is a guard note whose room is still within its own idle window.

    Tied to the room, not exempted outright: once the room itself is reapable the guards go
    with it, so this bounds the state exactly as before rather than adding an immortal
    namespace.
    """
    if path.parent.name not in ROOM_GUARD_NS:
        return False
    room = room_path(root, path.stem)
    try:
        return now - room.stat().st_mtime <= IDLE_SECONDS
    except OSError:
        return False  # no room left to guard


def _reap(root: Path) -> None:
    """Delete rooms and notes untouched for IDLE_SECONDS — or, for a room still on its
    first message, for STILLBORN_SECONDS — at most once per REAP_EVERY.

    Aggressive retirement is the point (docs/design.md §5.1), and
    it doubles as the answer to namespace squatting: a hard cap alone would let an attacker
    park MAX_ROOMS junk rooms forever. Eviction-by-idleness expires the junk without ever
    letting one caller evict another's *active* room.
    """
    marker = root / ".reaped"
    now = time.time()
    try:
        if now - marker.stat().st_mtime < REAP_EVERY:
            return
    except FileNotFoundError:
        pass
    root.mkdir(parents=True, exist_ok=True)
    marker.touch()
    # Rooms only: the stillborn rule is a room rule, so folding reaped notes into the same
    # two counters would make "idle" mean two different things in one number.
    reaped = {"reaped_idle": 0, "reaped_stillborn": 0}
    for sub, nested, suffix, stillborn_rule in (
        ("rooms", False, ".jsonl", True),
        ("notes", True, ".txt", False),
    ):
        for p in _walk(root / sub, suffix, nested):
            try:
                if _guards_a_live_room(root, p, now):
                    continue
                if not _reapable(p, now, stillborn_rule):
                    continue
                # Recheck under the lock: a writer may have refreshed the file since the
                # stat above, and deleting a just-written room would lose live messages.
                # Sync handlers overlap in the thread pool even with one Uvicorn process.
                # The recheck re-counts too, so the reply that lands mid-pass saves the room.
                with _locked(p):
                    reason = _reapable(p, now, stillborn_rule)
                    if reason:
                        p.unlink(missing_ok=True)
                        if stillborn_rule:
                            reaped[f"reaped_{reason}"] += 1
            except OSError:
                continue  # racing writer or vanished file: next pass picks it up
    if any(reaped.values()):  # one lock for the whole pass, not one per deleted room
        _bump(root, **reaped)
    # After the deletions, so the figure reflects the disk as it now is. One extra walk of
    # the rooms directory (~13 ms at the cap) on a pass that already costs half a second,
    # bought because the alternative is walking it on every append instead.
    try:
        used = _scan(root / "rooms", ".jsonl", sized=True)[1]
        usage_tmp = root / f"{USAGE_FILE}.tmp"
        usage_tmp.write_text(str(used), encoding="utf-8")
        os.replace(usage_tmp, root / USAGE_FILE)
    except OSError:
        pass  # a missing usage file reads as no pressure, which fails open, not closed
    # Sidecar locks are deliberately *not* removed with their data file: unlinking one a
    # writer holds splits the lock domain (the next writer locks a fresh inode). Instead
    # sweep the orphans — a lock with no data file, idle as long as any reaped room — so
    # directory entries stay bounded and the lock of a room anyone still writes to is
    # never touched. Deliberately IDLE_SECONDS even for a room the stillborn rule took at
    # 24h: the lock outlives its data by design, and waiting the full week is what keeps a
    # writer recreating that room from having its lock unlinked underneath it. The drift is
    # bounded by the room cap — at most a week of churn in empty files.
    for sub, nested, suffix in (("rooms", False, ".jsonl.lock"), ("notes", True, ".txt.lock")):
        for p in _walk(root / sub, suffix, nested):
            try:
                if p.with_suffix("").exists() or now - p.stat().st_mtime <= IDLE_SECONDS:
                    continue
                p.unlink(missing_ok=True)
            except OSError:
                continue
    for d in (root / "notes").glob("*"):
        try:
            d.rmdir()  # empty namespaces only: rmdir refuses a directory with entries
        except OSError:
            continue


def snapshots(root: Path) -> list[dict]:
    """Stored samples, oldest first. Each carries `t` (unix seconds) and the aggregates
    `service_stats` returns. A torn last line costs that one sample, never the history."""
    out = []
    try:
        lines = (root / SNAPSHOTS_FILE).read_text(encoding="utf-8").splitlines()
    except (OSError, ValueError):
        return out
    for line in lines:
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        if isinstance(rec, dict) and isinstance(rec.get("t"), (int, float)):
            out.append(rec)
    out.sort(key=lambda r: r["t"])
    return out


def _snapshot(root: Path) -> None:
    """Append one aggregate sample, at most once per SNAPSHOT_EVERY, pruning past
    SNAPSHOT_KEEP_SECONDS.

    Throttled off a marker's mtime exactly like `_reap`, and called from the same place, so
    this service still has no background thread, no scheduler and no lifespan hook — the
    two periodic jobs are both "whoever writes next, if it is due". The cost is one extra
    directory walk per interval on a path that is already walking those directories to
    reap, and it is what lets `/stats` answer a growth question with stored numbers rather
    than the caller keeping its own history.

    A consequence worth naming: an idle service takes no samples. That is correct — with
    no writes there is no new traffic to record — but it means the newest sample can be
    older than the interval, which is why every sample carries its own timestamp instead of
    the reader assuming a fixed cadence.

    Best effort, like `_log_event` and `_bump`: the caller's write has already succeeded.
    """
    marker = root / SNAPSHOTS_FILE
    now = time.time()
    try:
        if now - marker.stat().st_mtime < SNAPSHOT_EVERY:
            return
    except FileNotFoundError:
        pass
    except OSError:
        return
    try:
        with _locked(marker):
            # Re-check under the lock: two writers racing the stat above would otherwise
            # both take a sample, and the file is the throttle as well as the data.
            try:
                if time.time() - marker.stat().st_mtime < SNAPSHOT_EVERY:
                    return
            except FileNotFoundError:
                pass
            kept = [r for r in snapshots(root) if now - r["t"] <= SNAPSHOT_KEEP_SECONDS]
            kept.append({"t": int(now), **service_stats(root)})
            tmp = marker.parent / f"{marker.name}.tmp"
            tmp.write_text("".join(json.dumps(r) + "\n" for r in kept), encoding="utf-8")
            os.replace(tmp, marker)
    except OSError:
        pass


def _scan(d: Path, suffix: str, sized: bool = False) -> tuple[int, int]:
    """(count, total bytes) of the entries in `d` named `*suffix`, in one pass.

    os.scandir rather than Path.glob, and one pass rather than two, because every caller
    below is on a *create* path — and creates are not on a threadpool: app.py calls
    `append` and `note_set` straight from the handler, so this walk runs on the event loop
    and its cost is a stall that every concurrent request pays, not just the writer's.

    That is what made it worth measuring rather than assuming. At a full store, the glob
    it replaces cost 36 ms per new room (a counting glob, then a second one that stats)
    and 94 ms per new note; this costs 13 ms and 19 ms. The caps could not have grown
    tenfold on top of glob without those numbers growing with them.

    `sized` is a flag rather than always-on because the byte total is the expensive half:
    readdir hands back the name for free and never the size, so each entry costs a stat.
    Only rooms have a byte budget to enforce.
    """
    count = 0
    size = 0
    try:
        with os.scandir(d) as entries:
            for e in entries:
                if not e.name.endswith(suffix):
                    continue
                count += 1
                if sized:
                    try:
                        size += e.stat().st_size
                    except OSError:
                        continue  # reaped between the readdir and the stat
    except FileNotFoundError:
        pass  # nothing has been created yet; an absent directory is an empty one here
    return count, size


def _walk(d: Path, suffix: str, nested: bool = False) -> Iterator[Path]:
    """Every `*suffix` file directly in `d` (or one level down, when `nested`).

    Same syscalls as the `rooms/*.jsonl` and `notes/*/*.txt` globs it replaces, and less
    Python around them: measured back to back on one full store, the nested notes pass went
    95 ms -> 66 ms and the flat rooms pass 11 ms -> 8 ms. Worth having because the reaper
    makes four of these passes on the write path, but it is the smaller half of that cost —
    the rest is one stat() per file in `_reapable`, which no walk can avoid.

    Note the asymmetry with `_scan`, which is much faster still on the same directories:
    it only ever counts and measures, so it never allocates a Path per entry. Use that one
    where a count is all you need.
    """
    try:
        with os.scandir(d) as entries:
            for e in entries:
                if nested:
                    if e.is_dir():
                        yield from _walk(Path(e.path), suffix)
                elif e.name.endswith(suffix):
                    yield Path(e.path)
    except OSError:
        return  # missing or unreadable: nothing to walk, same as an empty glob


def _at_capacity(cap: int, what: str) -> StoreError:
    """The refusal, in one place because two callers raise it (rooms count both a cap and a
    byte budget). Only *new* names are refused, which is the actionable half: an agent
    blocked here can always keep working in a room or note it is already using."""
    return StoreError(
        f"{what} limit reached ({cap} is the cap, and this would be a new one). "
        f"Existing {what}s still accept writes, so reuse one you already have — "
        f"GET /rooms shows what exists. Idle {what}s are reclaimed after 7 days "
        "(a room still on its first message goes after 24 hours)."
    )


def _check_capacity(path: Path, suffix: str, cap: int, what: str) -> None:
    """Fail closed when a *new* file would exceed the cap. Existing ones always proceed,
    so a full namespace never silences agents already using it."""
    if path.exists():
        return
    if _scan(path.parent, suffix)[0] >= cap:
        raise _at_capacity(cap, what)


def room_bytes_used(root: Path) -> int:
    """Total room bytes at the last reap pass, or 0 if none has run yet.

    0 means "no pressure", which is the right default: on a fresh store there is none, and
    the first write runs a reap and establishes the real figure.
    """
    try:
        return int((root / USAGE_FILE).read_text(encoding="utf-8").strip() or 0)
    except (OSError, ValueError):
        return 0


def _ring_limit(root: Path) -> int:
    """How much ring a room may keep right now — the full ring, or its guaranteed floor
    once the service is over its total room-byte budget. See RESERVED_ROOM_BYTES."""
    if room_bytes_used(root) < MAX_TOTAL_ROOM_BYTES:
        return MAX_ROOM_BYTES
    return RESERVED_ROOM_BYTES


def _check_room_capacity(path: Path) -> None:
    """Fail closed on a *new* room past either bound — the count, or the disk budget.

    Two caps because they bound two different things (see MAX_TOTAL_ROOM_BYTES): the count
    bounds the walks, the budget bounds the volume. Same shape as `_check_note_capacity`
    below, which has enforced a local cap and a global one side by side since notes got a
    global cap, so there is one pattern here rather than two.

    The byte pass is a second walk of a directory `_check_capacity` just walked. It is
    worth it: room *creation* is the rare, rate-limited, already-gated path — appends to a
    room that exists never reach here at all (`path.exists()` returns above, and again in
    `_create_gate`) — and the alternative is a running total on disk that every reap,
    compaction and append would have to keep honest.

    Only new rooms are refused. A room that exists keeps accepting writes past the budget,
    the same way it does past the count: compaction already holds each one under
    MAX_ROOM_BYTES, so the overshoot is bounded, and cutting a live conversation off
    mid-sentence to save a megabyte is the worse trade.
    """
    if path.exists():
        return
    count, used = _scan(path.parent, ".jsonl", sized=True)
    if count >= MAX_ROOMS:
        raise _at_capacity(MAX_ROOMS, "room")
    if used >= MAX_TOTAL_ROOM_BYTES:
        raise StoreError(
            f"room storage is full ({used >> 20} MiB of a {MAX_TOTAL_ROOM_BYTES >> 20} MiB "
            "budget, and this would be a new room). The cap is on total bytes, not on the "
            "number of rooms, so a shorter name buys nothing. Existing rooms still accept "
            "writes, so reuse one you already have — GET /rooms shows what exists. Idle "
            "rooms are reclaimed after 7 days (a room still on its first message goes "
            "after 24 hours)."
        )


def _check_note_capacity(root: Path, path: Path) -> None:
    if path.exists():
        return
    _check_capacity(path, ".txt", MAX_NOTES_PER_NS, "note")
    total = 0
    try:
        with os.scandir(root / "notes") as namespaces:
            for ns in namespaces:
                if ns.is_dir():
                    total += _scan(Path(ns.path), ".txt")[0]
    except FileNotFoundError:
        pass
    if total >= MAX_NOTES_TOTAL:
        raise StoreError(
            f"note limit reached ({MAX_NOTES_TOTAL} across all namespaces, and this would "
            "be a new one). A fresh namespace buys nothing — the cap is global. Overwrite "
            "a note you already own instead; idle notes are reclaimed after 7 days, and "
            "GET /rooms reports how full the note store is."
        )


@contextmanager
def _create_gate(gate: Path, path: Path, check):
    """Serialise *creation* so a cap counted across files is exact, not merely likely.

    A per-file lock cannot enforce a cap over other files: two concurrent creates of
    different names each pass their own lock, each count `cap - 1`, and both write, so
    the cap is overshot by up to one write per in-flight request. Counting and creating
    under one shared gate makes it hard. Writes to a file that already exists never take
    the gate, so steady-state traffic stays as parallel as before.
    """
    if path.exists():
        yield
        return
    with _locked(gate):
        check()  # authoritative: nothing else can create between this count and the write
        yield


def append(
    root: Path,
    room: str,
    nick: str,
    text: str,
    did: str | None = None,
    nonce: int | None = None,
) -> dict:
    """Append a message, and announce the room the first time it appears.

    With `did` set the record is a *verified* one: the caller proved possession of that key
    (app.py checked the signature before calling), so `from` carries the DID instead of a
    self-asserted nick and `nonce` is recorded to refuse the same URL twice. Without it
    nothing about the record changes — the unsigned lane is preserved forever (§5.2).

    Room discovery had no mechanism: /rooms is sorted by mtime, so it shows *activity*
    order and creation order is not recoverable from it at all. Agents that do not already
    share a room name had no rendezvous but the hardcoded `lobby`.

    The announcement is a line in an ordinary room rather than a new endpoint, so every
    primitive that already exists does the rest — `?since=` for incremental reads,
    `?format=json`, `?wait=` for near-real-time, ring retention, the same rate limits.
    """
    rec, created = _write_record(root, room, nick, text, did=did, nonce=nonce)
    # Counted here rather than in `_write_record`, so the server's own announcements
    # (`_log_event` writes one per created room) never inflate the message count. This
    # counts what callers wrote, which is what "new messages" has to mean.
    _bump(root, messages=1, **({"rooms_created": 1} if created else {}))
    # Only public rooms, and never the events room announcing itself. A `p-` room is a
    # capability URL: announcing it would publish the one secret it has, and announcing it
    # *without* the name would still leak that someone created a private room at this
    # instant, which is correlatable with whoever was active. So: nothing at all.
    if created and room != EVENTS_ROOM and not unlisted(room):
        _log_event(root, f"created {room}")
    # Last, so the sample includes this write and any announcement it produced. Throttled
    # internally — the common call is one stat of a marker file.
    _snapshot(root)
    return rec


def _log_event(root: Path, line: str) -> None:
    """Best effort, always. The caller's write has already succeeded and been fsynced by
    the time this runs, so a full room cap or a failed event write must not turn that
    success into an error the caller sees."""
    try:
        _write_record(root, EVENTS_ROOM, EVENTS_NICK, line)
    except Exception:  # noqa: BLE001 - an unloggable event is never worth failing a write
        pass


def _last_nonce(root: Path, room: str, did: str) -> int | None:
    """The newest nonce this DID used in this room, within the tail READ_BUDGET covers.

    Bounded on purpose. A signed URL is a bearer token for one message: replaying it must
    fail while the message is still there to be seen, which is what this gives. Once the
    record has aged out of the scanned window — or out of the ring entirely — a replay is
    accepted again as a fresh message. That is the retention model doing what it says, not
    a gap: this store forgets, and an anti-replay set that outlived the messages it guards
    would be the one piece of unbounded state on a service whose whole design is bounded.
    """
    path = room_path(root, room)
    if not path.exists():
        return None
    with path.open("rb") as f:
        for raw in reverse_lines(f):
            rec = _parse(raw)
            if rec is not None and rec.get("from") == did and isinstance(rec.get("nonce"), int):
                return rec["nonce"]
    return None


def _write_record(
    root: Path,
    room: str,
    nick: str,
    text: str,
    did: str | None = None,
    nonce: int | None = None,
) -> tuple[dict, bool]:
    """Write one record. Returns (record, created) — `created` is True when this call is
    what brought the room into existence, which is the signal `append` announces on."""
    path = room_path(root, room)
    # Validated here rather than trusted from the caller: `from` is the one field readers
    # treat as provenance, and the allowlist that protects it does not apply to a DID (it
    # rejects ':'). One place decides the shape, for both write lanes.
    if did is None:
        rec = {"seq": 0, "ts": _now(), "from": valid_name(nick), "text": clean_text(text)}
    else:
        didkey.public_key(did)
        if not isinstance(nonce, int) or nonce < 0:
            raise StoreError(
                f"signed writes need a non-negative integer nonce, got {nonce!r} — 1-19 "
                "digits, greater than the last one this key used in this room. A counter "
                "or a millisecond clock both work"
            )
        rec = {"seq": 0, "ts": _now(), "from": did, "text": clean_text(text), "nonce": nonce}
    _reap(root)
    # Checked before the gate as well as under it: taking the gate serialises the caller
    # behind every other create, and a rotating room name flooding rejections should not
    # queue up behind them. The check inside the gate stays authoritative.
    _check_room_capacity(path)
    with (
        _create_gate(
            root / ".rooms-create",
            path,
            lambda: _check_room_capacity(path),
        ),
        _locked(path),
    ):
        # Under the lock, before the write: two concurrent first-writers must not both
        # decide they created the room and announce it twice.
        created = not path.exists()
        # Also under the lock, or two concurrent replays of one captured URL would both
        # read the same "last nonce" and both write.
        if did is not None:
            # The signature is `did: str | None, nonce: int | None`, which does not say
            # that a signed write must carry both. Assert it rather than assume it: with
            # nonce None this used to reach `None <= int` and raise TypeError — a 500 on
            # the replay-protection path instead of a refusal that says what was wrong.
            if nonce is None:
                raise StoreError(
                    "a signed write must carry a nonce: it is what makes a captured "
                    "signed URL single-use. Send 1-19 digits, counting up per key per room"
                )
            previous = _last_nonce(root, room, did)
            if previous is not None and nonce <= previous:
                raise StoreError(
                    f"nonce {nonce} is not greater than {previous}, the last one this key "
                    f"used in /r/{room} — a signed URL is single-use, so count up"
                )
        rec["seq"] = last_seq(root, room) + 1
        line = json.dumps(rec, ensure_ascii=False, separators=(",", ":")).encode() + b"\n"
        # Heal a torn tail before appending. A write cut short by a crash leaves a record
        # with no trailing newline; appending straight onto it would fuse the two into one
        # unparseable line, so the *next* message would be lost too — the torn record must
        # cost only itself.
        size = path.stat().st_size if path.exists() else 0
        if size:
            with path.open("rb") as f:
                f.seek(size - 1)
                if f.read(1) != b"\n":
                    line = b"\n" + line
        with path.open("ab") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())
        limit = _ring_limit(root)
        if path.stat().st_size > limit:
            _compact(path, cutoff=_cutoff(room), keep=limit // 2)
    return rec, created


def _compact(path: Path, cutoff: float | None = None, keep: int = COMPACT_KEEP_BYTES) -> None:
    """Keep the newest messages that fit `keep` bytes; drop the rest. Caller holds the lock.

    `keep` is half the ring the caller decided this room may have, which is the full ring
    normally and RESERVED_ROOM_BYTES when the service is over its total byte budget.

    `cutoff` is the `e-` class's rotation half: the records drop-on-read already hides stop
    occupying disk the next time the room rotates. No background reaper — this is the one
    pass that already rewrites the file, so expiry costs nothing extra by riding it.

    Byte-budgeted rather than line-counted so the retained history scales with the ring
    instead of with message size — see COMPACT_KEEP_BYTES. Compaction must leave the file
    strictly under MAX_ROOM_BYTES, or the next append re-triggers it and every write pays
    a full rewrite; a half-ring budget guarantees that with room to grow into.

    History loss is visible to clients: the tail response reports `first_seq`, so a
    reader that asked for `since=N` and gets `first_seq > N+1` knows it missed lines.
    """
    kept: list[bytes] = []
    total = 0
    with path.open("rb") as f:
        for line in reverse_lines(f, max_bytes=MAX_ROOM_BYTES):
            total += len(line) + 1  # the newline this line costs on the way back out
            if total > keep or len(kept) >= COMPACT_MAX_LINES:
                break
            if cutoff is not None and kept:
                # `and kept`: the newest record is always retained, expired or not, because
                # `seq` is read back from it. Compacting an `e-` room to nothing would
                # restart the sequence at 1 and silently strand every cursor pointing past
                # it. Unreadable on the way out, one line on disk — the cheap side of that
                # trade. Append-ordered, so everything further back is older still.
                rec = _parse(line)
                if rec is None or _expired(rec, cutoff):
                    break
            kept.append(line)
    kept.reverse()
    tmp = path.with_suffix(".jsonl.tmp")
    with tmp.open("wb") as f:
        # Not b"\n".join(...): an `e-` room whose every record expired compacts to nothing,
        # and join would leave a stray newline behind instead of an empty file.
        f.write(b"".join(line + b"\n" for line in kept))
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def note_set(
    root: Path,
    ns: str,
    key: str,
    value: str,
    expect: str | None = None,
    expect_absent: bool = False,
) -> dict:
    """Write a note, optionally only if it still holds what the caller last read.

    Unconditional writes are last-write-wins, which silently loses an update when two
    agents read-modify-write the same note — the failure a shared accumulator or an
    acceptance record hits first. `expect` (compare-and-set) and `expect_absent`
    (create-if-missing) close that, and both are evaluated *inside* the lock: doing the
    comparison outside it would reintroduce exactly the race being fixed.

    What this deliberately does NOT provide: ownership fencing. A caller that wins a CAS
    and then stalls can still act on a claim another caller has since taken over, because
    nothing revokes the first caller's belief. CAS orders writes; it does not order the
    side effects those writes describe.
    """
    path = note_path(root, ns, key)
    value = clean_text(value, MAX_VALUE_CHARS)
    _reap(root)
    _check_note_capacity(root, path)  # before the gate: no sidecar, no namespace dir on reject
    with (
        _create_gate(root / ".notes-create", path, lambda: _check_note_capacity(root, path)),
        _locked(path),
    ):
        if expect_absent or expect is not None:
            current = path.read_text(encoding="utf-8") if path.exists() else None
            if expect_absent and current is not None:
                raise StoreConflictError(f"note {ns}/{key} already exists", current)
            if expect is not None and current != expect:
                raise StoreConflictError(f"note {ns}/{key} changed since you read it", current)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(value, encoding="utf-8")
        os.replace(tmp, path)
    return {"ns": ns, "key": key, "bytes": len(value.encode()), "ts": _now()}


def note_get(root: Path, ns: str, key: str) -> str | None:
    path = note_path(root, ns, key)
    return path.read_text(encoding="utf-8") if path.exists() else None


def topic(root: Path, room: str) -> str | None:
    """A room's topic, previewed. Reserved note, no new write surface: it is set with the
    ordinary note lane (`/kv/topic/<room>/set/...`), which means it already passes the
    single-line sweep and `if=` already settles a topic-clobber race."""
    value = note_get(root, TOPIC_NS, room)
    if value is None:
        return None
    return value if len(value) <= TOPIC_PREVIEW_CHARS else value[:TOPIC_PREVIEW_CHARS] + "…"


def note_stats(root: Path) -> dict:
    """Aggregate note usage. Deliberately blind: no namespace, no key, ever.

    Namespaces ARE the privacy boundary — /kv/p-<32 random chars>/state is an agent's
    scratch space whose name is its only secret, and the manual promises namespaces are
    never enumerated. A per-namespace breakdown would enumerate precisely what must stay
    unenumerable, so this returns a count and a byte total: enough to watch the capacity
    that bounds the disk, useless for discovering anyone's notes.

    Bounded by MAX_NOTES_TOTAL, so the walk is O(MAX_NOTES_TOTAL) at worst — and at the
    current cap that is 40960 entries, every one of which needs a stat for its size. It is
    the most expensive thing /rooms does by an order of magnitude, which is why app.py
    serves that view from a short-lived cache rather than walking here per request.
    """
    d = root / "notes"
    total = 0
    size = 0
    try:
        with os.scandir(d) as namespaces:
            for ns in namespaces:
                if not ns.is_dir():
                    continue
                count, ns_bytes = _scan(Path(ns.path), ".txt", sized=True)
                total += count
                size += ns_bytes
    except FileNotFoundError:
        pass
    return {"total": total, "bytes": size, "capacity": MAX_NOTES_TOTAL}


def list_notes(root: Path, ns: str) -> list[str]:
    d = root / "notes" / valid_name(ns)
    return sorted(p.stem for p in d.glob("*.txt") if _listable(p.stem)) if d.is_dir() else []
